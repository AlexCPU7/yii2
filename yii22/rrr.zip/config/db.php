<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=yii2_v2',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8',
];

