console.log('Скрипт JS поделючён');
$('.container').append('<p>JS код</p>');