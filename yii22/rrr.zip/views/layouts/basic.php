<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="UTF-8">

<title>Basic</title>
</head>

<body>

    <h1>Basic</h1>

</body>
</html>