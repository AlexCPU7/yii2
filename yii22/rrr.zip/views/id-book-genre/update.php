<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\IdBookGenre */

$this->title = 'Update Id Book Genre: ' . $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Id Book Genres', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->id, 'url' => ['view', 'id' => $model->id]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="id-book-genre-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
